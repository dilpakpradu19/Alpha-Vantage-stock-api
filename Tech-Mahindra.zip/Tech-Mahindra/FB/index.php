<html>
<head>
<title>Facebook Login JavaScript Example</title>
<meta charset="UTF-8">
</head>
<style>
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="js/init.js"></script>
<script src="js/script.js"></script>
<body>
    <button id="login">Login with Facebook</button>
    <button style="display:none;" id="logout">Logout</button>          
    <div id="status">
    </div>
</body>
</html>