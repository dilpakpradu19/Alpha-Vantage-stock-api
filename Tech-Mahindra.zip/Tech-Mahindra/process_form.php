 <?php
// include_once 'db.php';
// if(isset($_POST['submit']))
// {    
//     $stock_symbol = $_POST['stock_symbol'];
//     $sql = "INSERT INTO users (stock_symbol) VALUES ('$stock_symbol')";
//     if (mysqli_query($conn, $sql)) {
//         echo "New record has been added successfully !";
//     } else {
//         echo "Error: " . $sql . ":-" . mysqli_error($conn);
//     }
//     mysqli_close($conn);
// }
?>

<?php
require_once "db.php";
// $data = json_decode($data,true);
// print_r($_POST['Global_Quote']);
$symbol = mysqli_real_escape_string($conn, $_POST['Global_Quote']['01. symbol']);
$open = mysqli_real_escape_string($conn, $_POST['Global_Quote']['02. open']);
$high = mysqli_real_escape_string($conn, $_POST['Global_Quote']['03. high']);
$low = mysqli_real_escape_string($conn, $_POST['Global_Quote']['04. low']);
$price = mysqli_real_escape_string($conn, $_POST['Global_Quote']['05. price']);
$volume = mysqli_real_escape_string($conn, $_POST['Global_Quote']['06. volume']);
$latest_trading_day = mysqli_real_escape_string($conn, $_POST['Global_Quote']['07. latest trading day']);
$latest_trending_day = date("d-m-Y", strtotime($latest_trading_day));
$previous_close = mysqli_real_escape_string($conn, $_POST['Global_Quote']['08. previous close']);

// $stock_symbol = mysqli_real_escape_string($conn, $_POST['stock_symbol']);
// $query = "INSERT INTO stock_details(symbol,high,low,price) VALUES('" . $symbol . "','" . $high . "''" . $low . "''" . $price . "')";
// print_r($query);
// exit;
if(mysqli_query($conn, "INSERT INTO stock_details(symbol,high,low,price) VALUES('" . $symbol . "','" . $high . "','" . $low . "','" . $price . "')")) {
       $return_arr[] = array("symbol" => $symbol,
                    "open" => $open,
                    "high" => $high,
                    "low" => $low,
                    "price" => $price,
                    "volume" => $volume,
                    "latest_trading_day" => $latest_trending_day,
                    "previous_close" => $previous_close);
// echo 'New record has been added successfully !';
       echo json_encode($return_arr);
} else {
echo "Error: " . $sql . "" . mysqli_error($conn);
}
mysqli_close($conn);
?>