-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2022 at 12:26 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tech_mahindra`
--

-- --------------------------------------------------------

--
-- Table structure for table `stock_details`
--

CREATE TABLE `stock_details` (
  `stock_details_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `symbol` varchar(16) NOT NULL,
  `high` float NOT NULL,
  `low` float NOT NULL,
  `price` float NOT NULL,
  `added_on` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_details`
--

INSERT INTO `stock_details` (`stock_details_id`, `user_id`, `symbol`, `high`, `low`, `price`, `added_on`) VALUES
(1, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 17:18:14'),
(2, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 17:32:46'),
(3, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 17:34:14'),
(4, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 17:34:28'),
(5, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 17:37:24'),
(6, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 17:39:50'),
(7, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 17:39:50'),
(8, 0, 'IBM', 134.18, 130.34, 130.38, '2022-08-27 17:39:57'),
(9, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 17:52:36'),
(10, 0, 'IBM', 134.18, 130.34, 130.38, '2022-08-27 17:57:11'),
(11, 0, '', 0, 0, 0, '2022-08-27 18:01:01'),
(12, 0, '', 0, 0, 0, '2022-08-27 18:01:03'),
(13, 0, '', 0, 0, 0, '2022-08-27 18:01:04'),
(14, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 18:03:18'),
(15, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 18:05:55'),
(16, 0, 'IBM', 134.18, 130.34, 130.38, '2022-08-27 18:05:58'),
(17, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 18:10:01'),
(18, 0, 'AMZN', 137.83, 130.5, 130.75, '2022-08-27 19:20:54');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `oauth_provider` enum('facebook','google','twitter','') COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `oauth_uid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stock_details`
--
ALTER TABLE `stock_details`
  ADD PRIMARY KEY (`stock_details_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stock_details`
--
ALTER TABLE `stock_details`
  MODIFY `stock_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
