<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Tech Mahindra Project</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  	<h2>Inline form</h2>
  	<form class="form-inline" action="javascript:void(0)" method="post">
	    <div class="form-group">
	      <label for="email">Stock Symbol</label>
	      <input type="text" class="form-control" id="stock_symbol" placeholder="Enter Stock Symbol" name="stock_symbol">
	    </div>
    <button type="submit" name="submit" id="submit" class="btn btn-default">Submit</button>
  	</form>
  	<h2>Stock Deatils</h2>
  	<table id="userTable" border="1" class="table">
      <thead>
        <tr>
          <th scope="col">S.no</th>
          <th scope="col">Symbol</th>
          <th scope="col">Open</th>
          <th scope="col">High</th>
          <th scope="col">Low</th>
          <th scope="col">Price</th>
          <th scope="col">Volume</th>
          <th scope="col">Latest Trading Day</th>
          <th scope="col">Prevoius Close</th>
        </tr>
      </thead>
      <tbody></tbody>
   </table>
</div>
<script>
$(document).ready(function(){
	$("#submit").click(function(){
		var stock_symbol = $("#stock_symbol").val();
		var dataString = 'stock_symbol=' + stock_symbol;
		var url = 'https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol='+stock_symbol +'&apikey=P54GZVRLUC6OT1JV';
		if(stock_symbol=='')
		{
			alert("Please enter stock symbol");
		}
		else
		{
			if (stock_symbol=='ibm' || stock_symbol=='amzn') {
							// AJAX Code To Submit Form.
			// $.ajax({
			// 	type: "POST",
			// 	url: "process_form.php",
			// 	data: dataString,
			// 	cache: false,
			// 	success: function(result){
			// 		alert(result);
			// 	}
			// });
			$.ajax({
				url: url, 
			    crossDomain: true,
			    dataType: "json",
			    success: function(data) {
			        console.log(data);
			        $.ajax({
						type: "POST",
						dataType: 'JSON',
						url: "process_form.php",
						data: data,
						cache: false,
						success: function(response){
							var len = response.length;
							for(var i=0; i<len; i++){
				                var symbol = response[i].symbol;
				                var open = response[i].open;
				                var high = response[i].high;
				                var low = response[i].low;
				                var price = response[i].price;
				                var volume = response[i].volume;
				                var latest_trading_day = response[i].latest_trading_day;
				                var previous_close = response[i].previous_close;

				                var tr_str = "<tr>" +
				                    "<td scope='row'>" + (i+1) + "</td>" +
				                    "<td>" + symbol + "</td>" +
				                    "<td>" + open + "</td>" +
				                    "<td>" + high + "</td>" +
				                    "<td>" + low + "</td>" +
				                    "<td>" + price + "</td>" +
				                    "<td>" + volume + "</td>" +
				                    "<td>" + latest_trading_day + "</td>" +
				                    "<td>" + previous_close + "</td>" +
				                    "</tr>";

				                $("#userTable tbody").append(tr_str);
            }
						}
					});
			    },
			    error: function (jqXHR, textStatus, error) {
			        console.log("Post error: " + error);
			    }
			});
		}else{
			alert('Please enter correct stock symbol. i.e. amzn or ibm');
			return false;
		}
		}
		return false;
	});
});
</script>
</body>
</html>